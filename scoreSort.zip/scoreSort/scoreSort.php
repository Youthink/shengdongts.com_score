<?php
/*
Plugin Name: scoreSort
Plugin URI: 
Description: 分数排名 报名信息查询
Version: 1.0
Author: Vic.Hu
Author URI: https://hufangyun.com


Copyright 2016  Vic.Hu  (email :hi@hufangyun.com)
 
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
 
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/
if( is_admin() ) {
    /*  利用 admin_menu 钩子，添加菜单 */
    add_action('admin_menu', 'display_scoreSort_menu');
    add_action('admin_menu', 'display_scoreSort_sub_add_menu');
}

function display_scoreSort_menu() {
    /* add_options_page( $page_title, $menu_title, $capability, $menu_slug, $function);  */
    /* 页名称，菜单名称，访问级别，菜单别名，点击该菜单时的回调函数（用以显示设置页面） */
    add_menu_page('Managed Score', '客户管理', 'administrator','display_score', 'display_score_html_page');
}

function display_score_html_page() {
    ?>
    <div style="text-align:center;margin-top:300px;">  
        <form method="post" action="<?php echo home_url('/vipscore/')?>"> 
            <input type="hidden" value="wordpressAdmin"/>   
            <input type="submit" value="点击进入客户管理平台" class="button-primary" style="font-size:20px;line-height:31px;height:68px;" /></p>   
        </form>
    </div>   
<?php  
}
 